
		<div class="header-bottom"><!--header-bottom-->
			<div class="container">
				<div class="row">
					<div class="col-sm-9">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
						<div class="mainmenu pull-left">
							<ul class="nav navbar-nav collapse navbar-collapse">
								 <li <?php if(\Route::current()->getName()=='products' ): ?> class="active" <?php endif; ?>><a href="<?php echo e(url('/')); ?>">Home</a></li>
								<li class="dropdown"><a href="#">Category<i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">
                                        
                                        <li>
                                            <a href="<?php echo e(asset("/")); ?>category/56"> 
           
                                            Electronics
                                         </a>
                                        </li>
                                         <li>
                                            <a href="<?php echo e(asset("/")); ?>category/57"> 
           
                                            Cloth
                                         </a>
                                        </li>
                                          <li>
                                            <a href="<?php echo e(asset("/")); ?>category/59"> 
           
                                            Bag
                                         </a>
                                        </li>
                                          <li>
                                            <a href="<?php echo e(asset("/")); ?>category/65"> 
           
                                            Watch
                                         </a>
                                        </li>
                                          <li>
                                            <a href="<?php echo e(asset("/")); ?>category/66"> 
           
                                            Bike
                                         </a>
                                        </li>
                                          <li>
                                            <a href="<?php echo e(asset("/")); ?>category/67"> 
           
                                            Ornaments
                                         </a>
                                        </li>
                                    
                                    </ul>
                                </li> 
								<li class="dropdown"><a href="#">Blog<i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">
                                        <li><a href="blog.html">Blog List</a></li>
										<li><a href="blog-single.html">Blog Single</a></li>
                                    </ul>
                                </li> 

								 <li <?php if(\Route::current()->getName()=='aboutus' ): ?> class="active" <?php endif; ?>><a href="<?php echo e(url('/')); ?>/about-us">About Us</a></li>
        <li  <?php if(\Route::current()->getName()=='contuctus' ): ?> class="active" <?php endif; ?>><a href="<?php echo e(url('/')); ?>/contact-us">Contact Us</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="search_box pull-right">
							<input type="text" placeholder="Search"/>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-bottom-->
	</header><!--/header-->
        <style type="text/css"> 
        .active {color:red;}
    </style>