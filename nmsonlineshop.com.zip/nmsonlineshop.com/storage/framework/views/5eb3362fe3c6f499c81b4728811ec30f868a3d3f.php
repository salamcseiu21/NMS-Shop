 <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <br>
        <section>
            
<div class="container">    
  <div class="row">

          <h2 class="title text-center">Our Products</h2>
             <?php $__currentLoopData = $data['all_products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <div class="col-sm-3" style="margin: 0;padding:5px;">
     
        <div class="panel-body text-center" style="background-color: white">
          
            <a href="<?php echo e(asset("/")); ?>product-details/<?php echo e($row->product_row_id); ?>" title="<?php echo e($row->product_name); ?>"> 
           
            <img src="<?php echo e(asset("/public/images/products/thumbs")); ?>/<?php echo e($row->product_image); ?>"  style="width:250px;height: 270px;" alt="Image">
                </a>
             <div class="row" style="margin-top:50px">
                                                    <div class="col-sm-6">Price:<?php echo e($row->product_price); ?> Tk</div>
                                                   <div class="col-sm-6"><a href="<?php echo e(asset("/")); ?>product-details/<?php echo e($row->product_row_id); ?>">Buy Now</a></div>
                                                </div>
            </div>

      
     </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
   
  </div>
</div>
  </section>
  <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>