
 <?php echo $__env->make('profile.user-layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<?php echo e($data['account-info']->email); ?>

<?php $__env->stopSection(); ?>

