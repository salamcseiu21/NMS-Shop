<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<br>
<section style="width: 100%;background-color: white;">
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                 <div class="container">
    
      <div class="row">
           
     <div class="col-md-5" style="padding: 0px;margin: 0;">
        
         <div class="panel-body" style="font-weight: bold;">
             <div class="row">
                 <div class="col-sm-3">
                       <a href="<?php echo e(asset("/")); ?>shop/<?php echo e($data["artisan"]->merchant_id); ?>" title="<?php echo e($data["artisan"]->shop_name); ?>"> <img src="<?php echo e(asset("/public/images/merchants")); ?>/<?php echo e($data["artisan"]->shop_image); ?>"  style="width:100px;height: 110px;" alt="Image" /></a>
                 </div>
                 <div class="col-sm-9" style="margin: 0;padding:0;">
                     &nbsp; <p style="text-transform: uppercase;margin: 0;padding:0;"><?php echo e($data["artisan"]->shop_name); ?></p>
                      <a href="#" class="btn"><?php echo e($data["artisan"]->shop_category); ?></a>
                 </div>
             </div>
          
           
        </div>
         
     </div>
       <div class="col-md-7">
           
        
      </div> 
        
         </div>
  </div>
            </div>
            <div class="col-sm-8">
                <div class="row">
                    
                    <div class="col-sm-10">
                          <?php $__currentLoopData = $data['all_products_by_category_id']->slice(0,4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-3" style="margin: 0;padding:0 5px">
            <div class="panel-body text-center" style="background-color: white">
               
                <a href="<?php echo e(asset("/")); ?>product-details/<?php echo e($row->product_row_id); ?>" title=" <?php echo e($row->product_name); ?>"> 

                    <img src="<?php echo e(asset("/public/images/products/thumbs")); ?>/<?php echo e($row->product_image); ?>"  style="width:100px;height: 110px;" alt="Image">
                </a>  
            </div>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
        <div class="col-sm-2" style="background-color: white;height: 125px;margin-top: 15px;">
            <div class="text-center" style="border:1px solid palegoldenrod;height: 110px;width: 100px;padding-top:40px">
                            <?php echo e($data['all_products_by_category_id']->Count()); ?> + Items
                        </div>
                        
                    </div>
                </div>
       
            </div>

        </div>
    </div>
</section>
<section>
    <div class="container">
         <div class="row" style="padding: 5px">

    <div class="col-md-5" style="padding-left:10px;padding-top: 30px">
        <div class="panel-body" style="padding:10px;background-color: white;">
            <a href="#" title="<?php echo e($data["product_detals_by_Id"]->product_name); ?>"> <img  data-toggle="modal" data-target="#myModal" src="<?php echo e(asset("/public/images/products/thumbs")); ?>/<?php echo e($data["product_detals_by_Id"]->product_image); ?>"  style="width:250px;height: 290px;" alt="Image" /></a>
        </div>
        <br>
       
        <div class="panel-body" style="padding:10px;background-color: white;">
            <div class="row">
                <div class="col-sm-5">
                     <label>PRODUCT DESCRIPTION</label><br>
                  <?php echo e($data["product_detals_by_Id"]->product_name); ?>

                </div>
                <div class="col-md-7" style="padding-top: 30px;padding-left: 0">
                   
                </div>
            </div>
             
        </div>
        <br>
         <div class="panel-body" style="padding:10px;background-color: white;">
            <div class="row">
                <div class="col-sm-5">
                     <label>ABOUT MERCHANT</label><br>
                  
            <a href="<?php echo e(asset("/")); ?>merchants-details/<?php echo e($data["artisan"]->merchant_id); ?>" title="<?php echo e($data["artisan"]->merchant_name); ?>"> <img src="<?php echo e(asset("/public/images/merchants")); ?>/<?php echo e($data["artisan"]->merchant_image); ?>"  style="width:100px;height: 110px;" class="img-circle" alt="Image" /></a>
                </div>
                <div class="col-md-7" style="padding-top: 30px;padding-left: 0">
                    <label><?php echo e($data["artisan"]->merchant_name); ?></label><br>
                     <?php echo e($data["artisan"]->about_merchant); ?>

                </div>
            </div>
             
        </div>
         
    </div>
    <div class="col-md-7" style="padding-top:30px;padding-right: 24px">
        <table class="table table-bordered" style="background-color: white">
            <tr>
                <td>
                    <p style="font-size: 15px;padding:0;"> <label> <?php echo e($data["product_detals_by_Id"]->product_name); ?></label><br>
                        NMS CODE : <?php echo e($data["product_detals_by_Id"]->product_sku); ?> <br>
                        PRICE : <?php echo e($data["product_detals_by_Id"]->product_price); ?> Tk
                    </p>        
                    <form action="<?php echo e(url('/')); ?>/addToCart" method="post">
                        <?php echo e(csrf_field()); ?>

                        <label>Quantity</label>
                        <input type="number" name="quantity" value="1" class="form-control" style="width: 160px;"/>
                        <input type="hidden" name="product_row_id" value="<?php echo e($data["product_detals_by_Id"]->product_row_id); ?>"/><br>
                        <input type="submit" name="submit" value="Add to Cart" class="btn btn-cart" style="background-color: darkcyan;color: white;padding-top: 5px;" />
                    </form>
                </td>
            </tr>
        </table>
        <table class="table table-bordered" style="background-color: white">
            <tr>
                <td>
                    <label>
                        PRODUCT'S OVERVIEW
                    </label>
                    <br>
                    <?php echo e($data["product_detals_by_Id"]->product_short_description); ?><br/>

                </td>
            </tr>
        </table>
        <div class="row"  style="background-color: white;margin: 0;padding: 0">
            <div class="col-sm-3" style="padding: 20px"> 
                <label>ABOUT SHOP</label>
                <br>
                  <a href="<?php echo e(asset("/")); ?>shop/<?php echo e($data["artisan"]->merchant_id); ?>" title="<?php echo e($data["artisan"]->shop_name); ?>"> <img src="<?php echo e(asset("/public/images/merchants")); ?>/<?php echo e($data["artisan"]->shop_image); ?>"  style="width:100px;height: 110px;" alt="Image" /></a>
                
            </div>
            <div class="col-sm-9" style="margin-top: 50px;padding-left: 0;padding-bottom: 20px">
                <label><?php echo e($data["artisan"]->shop_name); ?></label> <br>
                <i class="fa fa-location-arrow"></i> <?php echo e($data["artisan"]->shop_location); ?><br><br>
                  <?php echo e($data["artisan"]->about_shop); ?>

            </div>
        </div>
        
    </div> 


</div>
<!-- Trigger the modal with a button -->
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"><?php echo e($data['product_detals_by_Id']->product_name); ?></h4>
            </div>
            <div class="modal-body">
                <img  data-toggle="modal" data-target="#myModal" src="<?php echo e(asset('/public/images/products')); ?>/<?php echo e($data['product_detals_by_Id']->product_image); ?>" class="img-responsive" style="width:100%" alt="Image">

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>
    </div>
   
</section>
<section style="padding:0px">
    <h3 class="text-center" style="color: green;text-transform: uppercase;font-weight: bold">Related Products</h3>
</section>
<section>
    <div class="container">
        <div class="row">
 <div id="slider-carousel-related" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <div class="item active" style="padding:15px 30px">
                            <div class="col-sm-12">


                <div class="row">
                                    <?php $__currentLoopData = $data['all_products_by_category_id']->slice(0,4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-3" style="margin: 0;padding:5px;">
                                   
                                          <div class="product-image-wrapper" style="border-style:solid;border-width: 1px;border-color: pink;background-color: white">
                        <div class="single-products">
                            <div class="productinfo text-center">
                                <a  href="<?php echo e(asset("/")); ?>product-details/<?php echo e($row->product_row_id); ?>" title="<?php echo e($row->product_name); ?>"> 

                                    <img src="<?php echo e(asset("/public/images/products/thumbs")); ?>/<?php echo e($row->product_image); ?>"  style="width:170px;height: 200px;" alt="Image">
                                </a>
                                <h2 style="margin:0;padding: 7px"><?php echo e($row->product_price); ?> Tk</h2>
                                <p style="margin:0;padding-bottom: 7px"><?php echo e($row->product_name); ?></p>

                            </div>

                        </div>
                    </div>

                                        
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>




                            </div>
                        </div>
                     
                        <div class="item" style="padding:15px 30px">
                              <div class="col-sm-12">


                <div class="row">
                        
                                    <?php $__currentLoopData = $data['all_products_by_category_id']->take(-4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-3" style="margin: 0;padding:5px;">
                                        
                
                                          <div class="product-image-wrapper" style="border-style:solid;border-width: 1px;border-color: pink;background-color: white">
                        <div class="single-products">
                            <div class="productinfo text-center">
                                <a  href="<?php echo e(asset("/")); ?>product-details/<?php echo e($row->product_row_id); ?>" title="<?php echo e($row->product_name); ?>"> 

                                    <img src="<?php echo e(asset("/public/images/products/thumbs")); ?>/<?php echo e($row->product_image); ?>"  style="width:170px;height: 200px;" alt="Image">
                                </a>
                                <h2 style="margin:0;padding: 7px"><?php echo e($row->product_price); ?> Tk</h2>
                                <p style="margin:0;padding-bottom: 7px"><?php echo e($row->product_name); ?></p>

                            </div>

                        </div>
                    </div>

                                     
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>




                            </div>
                        </div>

                    </div>

     <a href="#slider-carousel-related" class="left control-carousel hidden-xs" data-slide="prev" style="margin: 0;padding:0;">
                         <i class="fa fa-arrow-circle-o-left" style="font-size:30px;margin-top:0"></i>
                    </a>
                    <a href="#slider-carousel-related" class="right control-carousel hidden-xs" data-slide="next" style="margin: 0;padding:0;">
                         <i class="fa fa-arrow-circle-o-right" style="font-size:30px;margin-top:0"></i>
                    </a>
                </div>
   

</div>
    </div>
</section>
<section style="padding:15px 20px">
    <p class="text-center"><a href="<?php echo e(url('/')); ?>/product-list"  class="btn btn-default" style="background-color: #63C6A7;color: white;border-radius: 20px;text-transform: uppercase;font-weight: bold">MORE PRODUCTS</a></p>
</section>
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>