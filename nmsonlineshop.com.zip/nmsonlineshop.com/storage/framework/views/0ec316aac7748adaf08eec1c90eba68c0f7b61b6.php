 <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">    
  <div class="row">
      <?php $__currentLoopData = $data['all_products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <div class="col-sm-4">
      <div class="panel panel-primary">
        <div class="panel-heading text-center"><?php echo e($row->product_name); ?></div>
        <div class="panel-body">
          
              <a href="<?php echo e(asset("/")); ?>product-details/<?php echo e($row->product_row_id); ?>"> 
           
            <img src="<?php echo e(asset("/public/images/products/thumbs")); ?>/<?php echo e($row->product_image); ?>"  style="width:250px;height: 250px;" alt="Image">
                </a>
            </div>
        <div class="panel-footer"> Price: <?php echo e($row->product_price); ?></div>
      </div>
     </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </div>
</div>
 
  <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>