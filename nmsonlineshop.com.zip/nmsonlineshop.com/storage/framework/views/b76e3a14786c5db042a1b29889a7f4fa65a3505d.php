 

<?php $__env->startSection('content-slider'); ?>
<div class="row" style="padding-right: 30px">
            <div class="col-sm-12">
                <div id="slider-carousel-featured" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <div class="item active" style="padding:15px 30px">
                            <div class="col-sm-12">


                <div class="row">
                                    <img src="<?php echo e(asset('/public/AdminAssets/images/home/image -3.jpg')); ?>" alt="" />

                                </div>




                            </div>
                        </div>
                     
                        <div class="item" style="padding:15px 30px">
                              <div class="col-sm-12">


                <div class="row">
                        
                                     <img src="<?php echo e(asset('/public/AdminAssets/images/home/image-2.jpg')); ?>" alt="" />

                                </div>




                            </div>
                        </div>
   <div class="item" style="padding:15px 30px">
                              <div class="col-sm-12">


                <div class="row">
                        
                                     <img src="<?php echo e(asset('/public/AdminAssets/images/home/image-1.jpg')); ?>" alt="" />

                                </div>




                            </div>
                        </div>
                    </div>

                    <a href="#slider-carousel-featured" class="left control-carousel hidden-xs" data-slide="prev">
                         <i class="fa fa-arrow-circle-o-left" style="font-size:30px;margin-left: 100px"></i>
                    </a>
                    <a href="#slider-carousel-featured" class="right control-carousel hidden-xs" data-slide="next">
                         <i class="fa fa-arrow-circle-o-right" style="font-size:30px;margin-right:50px"></i>
                    </a>
                </div>

            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>