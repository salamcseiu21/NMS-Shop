 

<?php $__env->startSection('content2'); ?>
<div class="row">
    <div class="col-sm-12">
        <div id="slider-carousel-featured" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="item active" style="padding: 30px">
                    <div class="col-sm-12">


                        <div class="row">

                            <?php $__currentLoopData = $data4['all_categories']->slice(0,3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-4" style="margin: 0;padding:5px;">


                                <div class="panel-body text-center" style="background-color: white">



                                    <img src="<?php echo e(asset("/public/images/products/thumbs")); ?>/<?php echo e($row->category_image); ?>"  style="width:250px;height: 250px;" alt="Image">
                                    <div class="row text-left" style="padding-top: 15px">
                                        <h3 style="padding-left: 15px;margin: 0;color: darkcyan;text-transform: uppercase;font-weight: bold"><?php echo e($row->category_name); ?></h3>

                                        <div class="col-sm-6">
                                            <div class="single-widget">

                                                <ul class="nav nav-pills nav-stacked" style="padding-left: 0;">
                                                    <li><a href="#">Online Help</a></li>
                                                    <li><a href="#">Contact Us</a></li>
                                                    <li><a href="#">Order Status</a></li>
                                                    <li><a href="#">Change Location</a></li>
                                                    <li><a href="#">FAQ’s</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="single-widget">

                                                <ul class="nav nav-pills nav-stacked" style="padding-left: 0;">
                                                    <li><a href="#">T-Shirt</a></li>
                                                    <li><a href="#">Mens</a></li>
                                                    <li><a href="#">Womens</a></li>
                                                    <li><a href="#">Gift Cards</a></li>
                                                    <li><a href="#">Shoes</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                </div>


                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>




                    </div>
                </div>



            </div>

        </div>

    </div>
</div>
<div class="row">
    <div class="col-sm-12">
        <div id="slider-carousel-featured" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="item active" style="padding: 30px">
                    <div class="col-sm-12">


                        <div class="row">

                            <?php $__currentLoopData = $data4['all_categories']->take(-3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-4" style="margin: 0;padding:5px;">


                                <div class="panel-body text-center" style="background-color: white">



                                    <img src="<?php echo e(asset("/public/images/products/thumbs")); ?>/<?php echo e($row->category_image); ?>"  style="width:250px;height: 250px;" alt="Image">

                                    <div class="row text-left" style="padding-top: 15px">
                                        <h3 style="padding-left: 15px;margin: 0;color: darkcyan;text-transform: uppercase;font-weight: bold"><?php echo e($row->category_name); ?></h3>

                                        <div class="col-sm-6">
                                            <div class="single-widget">

                                                <ul class="nav nav-pills nav-stacked" style="padding-left: 0px;">
                                                    <li><a href="#">Online Help</a></li>
                                                    <li><a href="#">Contact Us</a></li>
                                                    <li><a href="#">Order Status</a></li>
                                                    <li><a href="#">Change Location</a></li>
                                                    <li><a href="#">FAQ’s</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="single-widget">

                                                <ul class="nav nav-pills nav-stacked" style="padding-left: 0;">
                                                    <li><a href="#">T-Shirt</a></li>
                                                    <li><a href="#">Mens</a></li>
                                                    <li><a href="#">Womens</a></li>
                                                    <li><a href="#">Gift Cards</a></li>
                                                    <li><a href="#">Shoes</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>


                                </div>


                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>




                    </div>
                </div>



            </div>

        </div>

    </div>
</div>
<br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>