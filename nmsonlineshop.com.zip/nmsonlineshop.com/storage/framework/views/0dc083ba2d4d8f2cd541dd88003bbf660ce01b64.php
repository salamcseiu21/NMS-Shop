<?php $__env->startSection('categories-by-id-section'); ?> 
    <div class="row">
                    
                    <div class="col-sm-10">
                          <?php $__currentLoopData = $data['all_products_by_category_id']->slice(0,4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-3" style="margin: 0;padding:0 5px">
            <div class="panel-body text-center" style="background-color: white">
               
                <a href="<?php echo e(asset("/")); ?>product-details/<?php echo e($row->product_row_id); ?>" title=" <?php echo e($row->product_name); ?>"> 

                    <img src="<?php echo e(asset("/public/images/products/thumbs")); ?>/<?php echo e($row->product_image); ?>"  style="width:100px;height: 110px;" alt="Image">
                </a>  
            </div>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
        <div class="col-sm-2" style="background-color: white;height: 125px;margin-top: 15px;">
            <div class="text-center" style="border:1px solid palegoldenrod;height: 110px;width: 100px;padding-top:40px">
                            <?php echo e($data['all_products_by_category_id']->Count()); ?> + Items
                        </div>
                        
                    </div>
                </div>
       

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('single-product-details', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>