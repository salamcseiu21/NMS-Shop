<?php $__env->startSection('maincontent'); ?>
<h1>Total Product</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>