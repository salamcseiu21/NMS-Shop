<?php $__env->startSection('related-product-section'); ?> 
<div class="row">
 <div id="slider-carousel-related" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <div class="item active" style="padding:15px 30px">
                            <div class="col-sm-12">


                <div class="row">
                                    <?php $__currentLoopData = $data['all_products_by_category_id']->slice(0,4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-3" style="margin: 0;padding:5px;">
                                   
                                            <div class="panel-body text-center" style="background-color: white">

                                                <a href="<?php echo e(asset("/")); ?>product-details/<?php echo e($row->product_row_id); ?>" title=" <?php echo e($row->product_name); ?>"> 

                                                    <img src="<?php echo e(asset("/public/images/products/thumbs")); ?>/<?php echo e($row->product_image); ?>"  style="width:200px;height: 200px;" alt="Image">
                                                </a><br>
                                                  <div class="row" style="margin-top:50px">
                                                    <div class="col-sm-6">Price:<?php echo e($row->product_price); ?> Tk</div>
                                                   <div class="col-sm-6"><a href="<?php echo e(asset("/")); ?>product-details/<?php echo e($row->product_row_id); ?>">BUY NOW</a></div>
                                                </div>
                                            </div>

                                        
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>




                            </div>
                        </div>
                     
                        <div class="item" style="padding:15px 30px">
                              <div class="col-sm-12">


                <div class="row">
                        
                                    <?php $__currentLoopData = $data['all_products_by_category_id']->take(-4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-3" style="margin: 0;padding:5px;">
                                        

                                        <div class="panel-body text-center" style="background-color: white">

                                                <a href="<?php echo e(asset("/")); ?>product-details/<?php echo e($row->product_row_id); ?>" title=" <?php echo e($row->product_name); ?>"> 

                                                    <img src="<?php echo e(asset("/public/images/products/thumbs")); ?>/<?php echo e($row->product_image); ?>"  style="width:200px;height: 200px;" alt="Image">
                                                </a><br>
                                                <div class="row" style="margin-top:50px">
                                                    <div class="col-sm-6">Price:<?php echo e($row->product_price); ?> Tk</div>
                                                    <div class="col-sm-6"><a href="<?php echo e(asset("/")); ?>product-details/<?php echo e($row->product_row_id); ?>">BUY NOW</a></div>
                                                </div>
                                                
                                               
                                            </div>

                                     
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>




                            </div>
                        </div>

                    </div>

                    <a href="#slider-carousel-related" class="left control-carousel hidden-xs" data-slide="prev">
                         <i class="fa fa-arrow-circle-o-left" style="font-size:30px"></i>
                    </a>
                    <a href="#slider-carousel-related" class="right control-carousel hidden-xs" data-slide="next">
                         <i class="fa fa-arrow-circle-o-right" style="font-size:30px"></i>
                    </a>
                </div>
   

</div>


<?php $__env->stopSection(); ?> 
<?php echo $__env->make('single-product-details', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>