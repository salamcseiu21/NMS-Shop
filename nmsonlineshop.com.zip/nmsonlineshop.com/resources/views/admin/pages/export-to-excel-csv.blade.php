@extends('layouts.admin-layout')
@section('maincontent')
<div class="container">		
		<div class="panel panel-primary">
		  <div class="panel-heading">
		    <h3 class="panel-title" style="padding:12px 0px;font-size:25px;"><strong>Import sv or excel file</strong></h3>
		  </div>
		  <div class="panel-body">
		  	<div class="row">
		  		<div class="col-sm-2"></div>
		  		<div class="col-sm-8">
		  		<h3>Import File From Database:</h3>
		    	<div style="border: 4px solid #a1a1a1;margin-top: 15px;padding: 20px;"> 		
			    	<a href="{{ url('downloadExcel/xls') }}"><button class="btn btn-success btn-lg">Download Excel xls</button></a>
					<a href="{{ url('downloadExcel/xlsx') }}"><button class="btn btn-success btn-lg">Download Excel xlsx</button></a>
					<a href="{{ url('downloadExcel/csv') }}"><button class="btn btn-success btn-lg">Download CSV</button></a>
		    	</div>
		  		</div>
		  		<div class="col-sm-2"></div>
		  	</div>

		  		
		  </div>
		</div>
	</div>
@endsection