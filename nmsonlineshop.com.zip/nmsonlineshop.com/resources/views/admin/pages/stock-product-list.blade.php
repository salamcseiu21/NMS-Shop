
@extends('layouts.admin-layout')
@section('maincontent')
<h1>Total Product</h1>
@endsection